from flask import Flask, render_template, request
import os
import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import VotingClassifier
from sklearn.ensemble import GradientBoostingClassifier
from imblearn.over_sampling import SMOTE
from flask import *
import mysql.connector

db=mysql.connector.connect(user='root',port=3306,database='soft')
cur=db.cursor()

app = Flask(__name__)
app.config['upload folder']='uploads'


@app.route('/')
def index():
    return render_template('index.html')



@app.route('/login',methods=['POST','GET'])
def login():
    if request.method=='POST':
        email=request.form['Email']
        password=request.form['Password']
        cur.execute("select * from regi where Email=%s and Password=%s",(email,password))
        content=cur.fetchall()

        db.commit()
        if content == []:
            msg="Credentials Does't exist"
            return render_template('login.html',msg=msg)
        else:
            msg="Login Successful."
            return render_template('uhome.html',name=email,msg=msg)
    return render_template('login.html')




@app.route('/registration',methods=['POST','GET'])
def registration():
    if request.method=='POST':
        name=request.form['Name']
        email=request.form['Email']
        password1=request.form['Password']
        password2=request.form['Confirm Password']
        if password1 == password2:
            sql="select * from regi where Name='%s' and Email='%s'"%(name,email)
            cur.execute(sql)
            data=cur.fetchall()
            db.commit()
            print('----',data)
            if data==[]:
                sql="insert into regi(Name,Email,Password) values(%s,%s,%s)"
                val=(name,email,password1)
                cur.execute(sql,val)
                db.commit()
                return render_template('login.html')
            else:
                warning='Details already Exist'
                return render_template('registration.html',msg=warning)
        error='password not matched'
        flash(error)
    return render_template('registration.html')





@app.route('/uhome')
def uhome():
    return render_template('uhome.html')
global path




@app.route('/load data',methods=['POST','GET'])
def load_data():
    if request.method == 'POST':

        file = request.files['file']
        filetype = os.path.splitext(file.filename)[1]
        if filetype == '.csv':
            path = os.path.join(app.config['upload folder'], file.filename)
            file.save(path)
            print(path)
            return render_template('load data.html',msg = 'success')
        elif filetype != '.csv':
            return render_template('load data.html',msg = 'invalid')
        return render_template('load data.html')
    return render_template('load data.html')


@app.route('/view data',methods = ['POST','GET'])
def view_data():
    file = os.listdir(app.config['upload folder'])
    path = os.path.join(app.config['upload folder'],file[0])

    global df
    df = pd.read_csv(path)
    # df.drop('community', axis=1, inplace=True)


    print(df)
    return render_template('view data.html',col_name =df.columns.values,row_val = list(df.values.tolist()))


@app.route('/model',methods = ['POST','GET'])
def model():
    if request.method == 'POST':
        global scores1,scores2,scores3,scores4,scores5,scores6,scores7
        global df
        filename = os.listdir(app.config['upload folder'])
        path = os.path.join(app.config['upload folder'],filename[0])
        df = pd.read_csv(path)
        global testsize

        testsize =int(request.form['testing'])
        print(testsize)

        global x_train,x_test,y_train,y_test, model1, model2, model3, model4, model5, model6, model7
        testsize = testsize/100

        print(df)

        X = df.drop(['defects','id'],axis = 1)
        y = df.defects
        x_train,x_test,y_train,y_test = train_test_split(X,y,test_size =testsize,random_state = 10)
        sm = SMOTE()
        x_re, y_re = sm.fit_resample(x_train, y_train)
        x_train1, x_val, y_train1, y_val = train_test_split(x_re, y_re, test_size=0.3, random_state=10)

        model = int(request.form['selected'])
        if model == 1:
            lr = LogisticRegression()
            model1 = lr.fit(x_train1,y_train1)
            pred1 = model1.predict(x_val)
            # print('sdsj')
            scores1 = accuracy_score(y_val,pred1)
            # print('dsuf')
            return render_template('model.html',score = round(scores1,3),msg = 'accuracy',selected  = 'Logistic Regression')
        elif model == 2:
            rfc = RandomForestClassifier(n_estimators = 2,criterion = 'entropy',max_depth= 5)
            model2 = rfc.fit(x_train1,y_train1)
            pred2 = model2.predict(x_val)
            scores2 =accuracy_score(y_val,pred2)
            return render_template('model.html',msg = 'accuracy',score = round(scores2,3),selected = 'RANDOM FOREST CLASSIFIER')
        elif model == 3:
            svc = SVC()
            model3 = svc.fit(x_train1,y_train1)
            pred3 = model3.predict(x_val)
            scores3 = accuracy_score(y_val,pred3)
            return render_template('model.html',msg = 'accuracy',score = round(scores3,3),selected = 'SUPPORT  VECTOR  CLASSIFIER ')
        elif model == 4:
            nb = DecisionTreeClassifier()
            model4 = nb.fit(x_train1,y_train1)
            pred4 = model4.predict(x_val)
            scores4 = accuracy_score(y_val,pred4)
            return render_template('model.html',msg = 'accuracy',score = round(scores4,3),selected = 'Decision Tree Classifier')
        elif model == 5:
            knn = KNeighborsClassifier()
            model5 = knn.fit(x_train1,y_train1)
            pred5 = model5.predict(x_val)
            scores5 = accuracy_score(y_val,pred5)
            return render_template('model.html',msg = 'accuracy',score = round(scores5,3),selected = 'KNeighbors Classifier')
        elif model == 6:
            ab = GradientBoostingClassifier()
            model6 = ab.fit(x_train1,y_train1)
            pred6 = model6.predict(x_val)
            scores6 = accuracy_score(y_val,pred6)
            return render_template('model.html',msg = 'accuracy',score = round(scores6,3),selected = 'Gradient Boosting Classifier')

        elif model == 7:
            models = [('logistic', model1),('random_forest', model2), ('SVC', model3), ('Decision Tree', model4), ('KNN',model5),('Gradient boosting', model6)]
            vc = VotingClassifier(estimators = models,voting= 'hard')
            model7 = vc.fit(x_train1,y_train1)
            pred7 = model7.predict(x_val)
            scores7 = accuracy_score(y_val,pred7)
            return render_template('model.html',msg = 'accuracy',score = round(scores7,3),selected = 'Voting Classifier')

    return render_template('model.html')


@app.route('/prediction',methods=['POST','GET'])
def prediction():
    print('111111')
    if  request.method == 'POST':

        a = request.form['a']
        b = request.form['b']
        c = request.form['c']
        d = request.form['d']
        e = request.form['e']
        f = request.form['f']
        g = request.form['g']
        h = request.form['h']
        i = request.form['i']
        j = request.form['j']
        k = request.form['k']
        l = request.form['l']
        m = request.form['m']
        n = request.form['n']
        o = request.form['o']
        p = request.form['p']
        q = request.form['q']
        r = request.form['r']
        s = request.form['s']
        t = request.form['t']
        u = request.form['u']
        v = request.form['v']
        w = request.form['w']
        x = request.form['x']
        y = request.form['y']
        z = request.form['z']
        a1 = request.form['a1']
        a2 = request.form['a2']
        a3 = request.form['a3']
        a4 = request.form['a4']
        a5 = request.form['a5']
        a6 = request.form['a6']
        a7 = request.form['a7']
        a8 = request.form['a8']
        a9 = request.form['a9']
        a10 = request.form['a10']




        abc= [a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10]

        model = RandomForestClassifier(n_estimators=20)
        model.fit(x_train,y_train)
        result = model.predict([abc])

        print(result)
        if  result == 0:
            msg = ' Software Has Defects'
        else:
            msg = "Software Has No Defects"
        return render_template('prediction.html',msg=msg)

    return render_template('prediction.html')


@app.route('/logout')
def logout():
    return redirect(url_for('index'))



if __name__ == '__main__':
    app.run(debug=True)